//
//  PhotoCollectionViewCell.swift
//  CameraFilter
//
//  Created by Kamil Gucik on 14/05/2020.
//  Copyright © 2020 Kamil Gucik. All rights reserved.
//

import Foundation
import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var photoImageView: UIImageView!
}
